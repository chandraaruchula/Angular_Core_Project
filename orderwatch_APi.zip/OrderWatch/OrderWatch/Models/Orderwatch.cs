﻿using System.ComponentModel.DataAnnotations;
using System.Data;

namespace OrderWatch.Models
{
    public class Orderwatch
    {
        [Key]
        public int orderId { get; set; }
        public DateTime dateofOrder { get; set; }
        public string ordertype { get; set; }
        public string milestonesStatus { get; set; }
        public int totalcharge { get; set; }
        public string origin { get; set; }
        public string destination { get; set; }
        public bool urgentdelivery { get; set; }    


    }
}
