﻿using Microsoft.EntityFrameworkCore;

namespace OrderWatch.Models
{
    public class OrderwatchDbContext: DbContext
    {
        public OrderwatchDbContext(DbContextOptions<OrderwatchDbContext> options) : base(options) { 
        }

        public DbSet<Orderwatch> Orderwatch { get; set; }
        public DbSet<DropDown>  DropDown { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=P0181314; Initial Catalog=OrderWatch; User Id=sa; password=P0181314; TrustServerCertificate=True");    
        }
    }
}
