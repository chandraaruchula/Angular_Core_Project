﻿namespace OrderWatch.Models
{
    public class DropDown
    {
        public int Id { get; set; }
        public string country { get; set; }
        public string ordertype { get; set; }
        public string milestonestatus { get; set; }
    }
}
