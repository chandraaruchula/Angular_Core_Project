﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderWatch.Models;

namespace OrderWatch.Controllers
{
    public class OriginController : ControllerBase
    {
        private readonly OrderwatchDbContext _orderwatchDbContext;
        public OriginController(OrderwatchDbContext orderwatchDbContext)
        {
            _orderwatchDbContext = orderwatchDbContext;
        }
        [HttpGet]
        [Route("GetDropDown")]
        public async Task<IEnumerable<DropDown>> GetDropDown()
        {
            return await _orderwatchDbContext.DropDown.ToListAsync();
        }
    }
}
