﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OrderWatch.Models;

namespace OrderWatch.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderwatchController : ControllerBase
    {
        private readonly OrderwatchDbContext _orderwatchDbContext;
        public OrderwatchController(OrderwatchDbContext orderwatchDbContext)
        {
            _orderwatchDbContext = orderwatchDbContext;
        }
        [HttpGet()]
        public async Task<IEnumerable<Orderwatch>> GetOrderwatch()
        {
            return await _orderwatchDbContext.Orderwatch.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<Orderwatch> Getbyid(int id)
        {
            var response = _orderwatchDbContext.Orderwatch.SingleOrDefault(x => x.orderId == id);
            return response;
        }
        [HttpPost]
        public async Task<Orderwatch> AddOrderwatch(Orderwatch objOrderwatch)
        {
            _orderwatchDbContext.Orderwatch.Add(objOrderwatch);
            await _orderwatchDbContext.SaveChangesAsync();
            return objOrderwatch;
        }

        [HttpPut("{id}")]
        
        public async Task<Orderwatch> UpdateOrderwatch(Orderwatch objOrderwatch)
        {
            _orderwatchDbContext.Entry(objOrderwatch).State = EntityState.Modified;
            await _orderwatchDbContext.SaveChangesAsync();
            return objOrderwatch;
        }

        [HttpDelete("{id}")]
    
        public bool DeleteOrderwatch(int id)
        {
            bool a = false;
            var orderwatch = _orderwatchDbContext.Orderwatch.Find(id);
            if (orderwatch != null)
            {
                a = true;
                _orderwatchDbContext.Entry(orderwatch).State = EntityState.Deleted;
                _orderwatchDbContext.SaveChanges();
            }
            else
            {
                a = false;
            }
            return a;

        }
    }
}
